import { recalculerCanevas, type CelluleCalcul } from "@/lib/calculs-canevas";
import { ConnexionDonnees } from "@/components/connexion-donnees";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api-client";
import { useOfficine } from "@/lib/officine-context";
import { Button } from "@/components/ui/button";
import { SelecteurFiltrable } from "@/components/ui/selecteur-filtrable";
import { Dialog } from "@/components/ui/dialog";
import { ModaleFiche, ColonneFiche } from "@/components/modules/modale";
interface Cellule extends CelluleCalcul { cle: string; texte: string; largeur: number; hauteur: number; fond?: string; gras?: boolean; images?: string[]; imbriques?: Bloc[] }
interface Bloc { cle: string; type: "paragraphe" | "tableau"; texte?: string; gras?: boolean; alignement?: string; images?: string[]; lignes?: Cellule[][]; largeurs?: number[] }
export interface Canevas { usage?: "reference"; format?: string; id: string; titre: string; rubrique: string; fichier: string; sha256: string; parties: { origine: string; blocs: Bloc[] }[]; images: Record<string, string> }
interface Rempli { schema: string; canevas: Canevas; valeurs: Record<string, string> }
export function lireCanevas(contenu: string): Rempli | null {
  try {
    const c = JSON.parse(contenu);
    return c?.schema === "begpharma.canevas-rempli.v1" && Array.isArray(c.canevas?.parties) && c.valeurs && typeof c.valeurs === "object" ? c : null;
  } catch { return null; }
}
export function ContenuCanevas({ canevas, valeurs, changer }: { canevas: Canevas; valeurs: Record<string, string>; changer?: (cle: string, valeur: string) => void }) {
  const [feuille, setFeuille] = useState(canevas.parties[0]?.origine ?? "");
  const feuilleCourante = canevas.parties.some(p => p.origine === feuille) ? feuille : canevas.parties[0]?.origine;
  const calculees = new Set(canevas.parties.flatMap(p => p.blocs.flatMap(b => b.lignes?.flat().filter(c => c.calcul).map(c => c.cle) ?? [])));
  const valeursCalculees = recalculerCanevas(canevas, valeurs);
  const texte = (cle: string, original = "") => valeursCalculees[cle] ?? original;
  const zone = (cle: string, original: string, label: string) => changer && !calculees.has(cle) ? <textarea aria-label={label} className="min-h-12 w-full min-w-0 resize-y rounded border border-emerald-200 bg-white p-2 text-sm leading-relaxed focus:border-emerald-700" rows={Math.min(15, Math.max(2, original.split("\n").length))} value={texte(cle, original)} onChange={e => changer(cle, e.target.value)} /> : <span className="whitespace-pre-wrap">{texte(cle, original) || "\u00a0"}</span>;
  const blocs = (liste: Bloc[]) => liste.map((b, i) => b.type === "tableau" ? <div key={b.cle} className="max-w-full overflow-x-auto"><table className="w-full border-collapse border border-slate-300 text-sm"><colgroup>{b.largeurs?.map((largeur, i) => <col key={i} style={{ width: `${largeur / b.largeurs!.reduce((a, v) => a + v, 0) * 100}%` }} />)}</colgroup><tbody>{b.lignes?.map((ligne, l) => <tr key={l}>{ligne.map((cell, c) => <td key={cell.cle} colSpan={cell.largeur} rowSpan={cell.hauteur} className="min-w-32 border border-slate-300 p-2 align-top" style={{ backgroundColor: /^#[a-fA-F0-9]{6}$/.test(cell.fond ?? "") ? cell.fond : undefined, fontWeight: cell.gras ? "bold" : undefined }}>
    {cell.images?.map(image => canevas.images[image] && <img key={image} src={canevas.images[image]} alt="Illustration du modèle source" className="max-h-32 max-w-full object-contain" />)}
    {zone(cell.cle, cell.texte, `Cellule du tableau, ligne ${l + 1}, colonne ${c + 1}`)}{cell.imbriques && blocs(cell.imbriques)}
  </td>)}</tr>)}</tbody></table></div> : <div key={b.cle} className={b.gras ? "font-bold" : ""} style={{ textAlign: ["center", "right", "justify"].includes(b.alignement ?? "") ? b.alignement as "center" | "right" | "justify" : "left" }}>
    {b.images?.map(image => canevas.images[image] && <img key={image} src={canevas.images[image]} alt="Illustration du modèle source" className="max-h-32 max-w-full object-contain" />)}
    {zone(b.cle, b.texte ?? "", `Paragraphe du modèle ${i + 1}`)}
  </div>);
  return <div className="grid min-w-0 gap-5">{canevas.format === "xlsx" && <SelecteurFiltrable etiquette="Feuille du classeur" valeur={feuilleCourante ?? ""} onChange={setFeuille} options={canevas.parties.map(p => ({ valeur: p.origine, libelle: p.origine }))} />}{canevas.parties.filter(p => canevas.format !== "xlsx" || p.origine === feuilleCourante).map(partie => <section key={partie.origine} className="grid min-w-0 gap-3">{canevas.format === "pdf" && <h3 className="font-bold">{partie.origine}</h3>}{blocs(partie.blocs)}</section>)}</div>;
}
export function CanevasCatalogue({ officine, filtre = "tous", creer = true }: { officine: string; filtre?: "tous" | "procedures" | "qualite"; creer?: boolean }) {
  const qc = useQueryClient();
  const [choix, setChoix] = useState("");
  const [processus, setProcessus] = useState("");
  const [typeDoc, setTypeDoc] = useState("procedure");
  const [ouvert, setOuvert] = useState(false);
  const [valeurs, setValeurs] = useState<Record<string, string>>({});
  const [message, setMessage] = useState("");
  const [enCours, setEnCours] = useState(false);
  const liste = useQuery({ refetchOnMount: "always", queryKey: ["canevas-catalogue", officine], queryFn: async () => { const donnees = await api.get<Canevas[]>(`/officines/${officine}/canevas`); if (!Array.isArray(donnees)) throw new Error("Catalogue indisponible."); return donnees; } });
  const modele = useQuery({ queryKey: ["canevas", officine, choix], enabled: !!choix, queryFn: () => api.get<Canevas>(`/officines/${officine}/canevas/${choix}`) });
  const candidats = (liste.data ?? []).filter(c => filtre === "tous" || (filtre === "procedures" ? /^(PRO|CANEVAS)|Liste des procédures/i.test(c.titre) : /non.conform|amélioration|auto.inspection|réclamation/i.test(c.titre)));
  useEffect(() => { if (!choix && candidats.length) setChoix(candidats[0].id); }, [choix, candidats]);
  const peutCompleter = creer && modele.data?.usage !== "reference";
  async function enregistrer() {
    if (!peutCompleter) return;
    setMessage(""); setEnCours(true);
    try {
      const resultat = await api.post<{ mode_demo?: boolean }>(`/officines/${officine}/canevas/${choix}/documents`, { valeurs, processus, type_doc: typeDoc });
      await qc.invalidateQueries({ queryKey: ["documents"] });
      await qc.invalidateQueries({ queryKey: ["documents-adoptions"] });
      setOuvert(false); setValeurs({}); setMessage(resultat.mode_demo ? "Brouillon de démonstration conservé localement dans l’aperçu. Ce n’est pas un registre de production." : "Brouillon enregistré dans les documents de l’officine. Vous pouvez le relire puis demander son approbation.");
    } catch (e) { setMessage(e instanceof Error ? e.message : "Enregistrement impossible."); }
    finally { setEnCours(false); }
  }
  return <section className="grid gap-3 rounded-xl border border-emerald-100 bg-white p-4">
    <h2 className="text-lg font-bold">Modèles et références</h2>
    <p className="text-sm text-muted-foreground">Choisissez un modèle à compléter ou un document de référence à consulter.</p>
    {liste.isError ? <ConnexionDonnees erreur={liste.error} reessayer={() => liste.refetch()} titre="Modèles en attente de chargement" /> : <SelecteurFiltrable etiquette="Modèle source" valeur={choix} options={candidats.map(c => ({ valeur: c.id, libelle: c.titre, description: c.usage === "reference" ? "Document de référence annoté" : c.rubrique }))} onChange={c => { setChoix(c); setValeurs({}); setMessage(""); }} />}
    {modele.data && <details className="rounded-xl border p-3"><summary className="min-h-12 cursor-pointer font-bold">Aperçu du document</summary><ContenuCanevas canevas={modele.data} valeurs={{}} /></details>}
    <Button variant="outline" className="min-h-12 justify-self-start" disabled={!modele.data || modele.isError} onClick={() => setOuvert(true)}>{peutCompleter ? "Compléter ce modèle" : "Consulter le document"}</Button>
    {modele.isError && <ConnexionDonnees erreur={modele.error} reessayer={() => modele.refetch()} titre="Le modèle ne peut pas être ouvert" />}
    {message && <p role="status">{message}</p>}
    <Dialog open={ouvert} onOpenChange={o => { if (!enCours) setOuvert(o); }}><ModaleFiche titre={modele.data?.titre ?? "Canevas"} sousTitre={modele.data?.usage === "reference" ? "Les annotations du document source sont conservées pour consultation, sans validation réglementaire implicite." : "Complétez le modèle avant de l’enregistrer comme brouillon."} pied={<div className="flex flex-wrap justify-end gap-3"><Button variant="outline" className="min-h-12" disabled={enCours} onClick={() => setOuvert(false)}>Fermer</Button>{peutCompleter && <Button className="min-h-12" disabled={enCours || !processus} onClick={enregistrer}>{enCours ? "Enregistrement…" : "Enregistrer le brouillon"}</Button>}</div>}>
      {modele.data && <div className="grid min-w-0 gap-5 md:grid-cols-[minmax(0,1fr)_minmax(0,3fr)]"><ColonneFiche titre="Document source">{peutCompleter && <><SelecteurFiltrable etiquette="Nature du document" valeur={typeDoc} onChange={setTypeDoc} options={[{ valeur: "procedure", libelle: "Procédure" }, { valeur: "enregistrement", libelle: "Formulaire ou enregistrement" }, { valeur: "fiche_poste", libelle: "Fiche de poste" }]} /><SelecteurFiltrable etiquette="Processus à confirmer" valeur={processus} onChange={setProcessus} options={[{ valeur: "TAM", libelle: "Management" }, { valeur: "QAM", libelle: "Qualité et amélioration" }, { valeur: "GAD", libelle: "Dispensation" }, { valeur: "GAC", libelle: "Approvisionnement et stocks" }, { valeur: "GAR", libelle: "Ressources et locaux" }]} /></>}<p className="break-words text-sm">{modele.data.fichier}</p>{modele.data.format === "xlsx" && <p className="text-xs text-amber-800">Les soldes de congés et les produits de cotation des risques sont recalculés. Les autres calculs et les codes restent à vérifier.</p>}<p className="text-xs text-muted-foreground">{modele.data.usage === "reference" ? "Le texte et les annotations sont présentés pour consultation." : "Les zones et tableaux du modèle sont repris pour la saisie. La présentation s’adapte à l’écran."}</p>{message && <p role="alert">{message}</p>}</ColonneFiche><ColonneFiche titre={modele.data.usage === "reference" ? "Contenu et annotations" : "Zones du canevas"}><ContenuCanevas canevas={modele.data} valeurs={valeurs} changer={peutCompleter ? (cle, valeur) => setValeurs(v => ({ ...v, [cle]: valeur })) : undefined} /></ColonneFiche></div>}
    </ModaleFiche></Dialog>
  </section>;
}
export function PageCatalogueCanevas() {
  const { courante, aRole } = useOfficine();
  return <div className="grid gap-5"><h1 className="text-2xl font-bold">Bibliothèque des modèles qualité</h1>{courante && <CanevasCatalogue key={courante.officine_id} officine={courante.officine_id} creer={aRole("promoteur", "pharmacien_titulaire", "pharmacien_adjoint", "rmq")} />}</div>;
}
export const echapperCanevas = (s: string) => s.replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
export function htmlCanevas(contenu: string): string {
  const r = lireCanevas(contenu);
  if (r) r.valeurs = recalculerCanevas(r.canevas, r.valeurs);
  if (!r) return `<p style="white-space:pre-wrap">${echapperCanevas(contenu)}</p>`;
  const images = (ids: string[] = []) => ids.map(id => {
    const data = r.canevas.images[id];
    return typeof data === "string" && /^data:image\/(png|jpeg|gif);base64,[A-Za-z0-9+/=]+$/.test(data) ? `<img src="${data}" alt="Illustration du modèle source" style="max-height:120px;max-width:100%" />` : "";
  }).join("");
  const blocs = (liste: Bloc[]): string => liste.map(b => b.type === "tableau" ? `<table style="width:100%;border-collapse:collapse"><tbody>${b.lignes?.map(l => `<tr>${l.map(c => `<td colspan="${c.largeur}" rowspan="${c.hauteur}" style="border:1px solid #aaa;padding:8px;white-space:pre-wrap">${images(c.images)}${echapperCanevas(r.valeurs[c.cle] ?? c.texte)}${c.imbriques ? blocs(c.imbriques) : ""}</td>`).join("")}</tr>`).join("")}</tbody></table>` : `<p style="white-space:pre-wrap">${images(b.images)}${echapperCanevas(r.valeurs[b.cle] ?? b.texte ?? "")}</p>`).join("");
  return r.canevas.parties.map(p => blocs(p.blocs)).join("\n");
}
export function texteCanevas(contenu: string): string {
  const r = lireCanevas(contenu);
  if (!r) return contenu;
  r.valeurs = recalculerCanevas(r.canevas, r.valeurs);
  const blocs = (liste: Bloc[]): string => liste.map(b => b.type === "tableau" ? b.lignes?.map(l => l.map(c => (r.valeurs[c.cle] ?? c.texte) + (c.imbriques ? blocs(c.imbriques) : "")).join(" | ")).join("\n") : r.valeurs[b.cle] ?? b.texte ?? "").join("\n");
  return r.canevas.parties.map(p => blocs(p.blocs)).join("\n");
}
export function EditionCanevas({ contenu, officine, document, empreinte, actualiser }: { contenu: string; officine: string; document: string; empreinte: string; actualiser: () => Promise<void> }) {
  const r = lireCanevas(contenu);
  const [ouvert, setOuvert] = useState(false);
  const [valeurs, setValeurs] = useState(r?.valeurs ?? {});
  const [erreur, setErreur] = useState("");
  const [enCours, setEnCours] = useState(false);
  if (!r) return null;
  return <><Button variant="outline" className="min-h-12" onClick={() => { setValeurs(r.valeurs); setErreur(""); setOuvert(true); }}>Compléter les zones du document</Button>
    <Dialog open={ouvert} onOpenChange={o => { if (!enCours) setOuvert(o); }}><ModaleFiche titre="Compléter le document" sousTitre="Les modifications restent dans le brouillon de l’officine." pied={<div className="flex justify-end gap-3"><Button variant="outline" className="min-h-12" disabled={enCours} onClick={() => setOuvert(false)}>Annuler</Button><Button className="min-h-12" disabled={enCours} onClick={async () => {
      setEnCours(true); setErreur("");
      try { await api.put(`/officines/${officine}/documents/${document}`, { contenu: JSON.stringify({ ...r, valeurs }), empreinte_edition: empreinte }); await actualiser(); setOuvert(false); }
      catch (e) { setErreur(e instanceof Error ? e.message : "Enregistrement impossible."); }
      finally { setEnCours(false); }
    }}>Enregistrer les modifications</Button></div>}><div className="grid gap-5 md:grid-cols-[minmax(0,1fr)_minmax(0,3fr)]"><ColonneFiche titre="Version de travail"><p className="text-sm">Relisez les zones complétées avant de demander l’approbation.</p>{erreur && <p role="alert">{erreur}</p>}</ColonneFiche><ColonneFiche titre="Canevas"><ContenuCanevas canevas={r.canevas} valeurs={valeurs} changer={(cle, valeur) => setValeurs(v => ({ ...v, [cle]: valeur }))} /></ColonneFiche></div></ModaleFiche></Dialog></>;
}
