import { createFileRoute, Outlet } from "@tanstack/react-router";
export const Route = createFileRoute("/_authenticated/dashboard")({ ssr: false, component: Outlet });
